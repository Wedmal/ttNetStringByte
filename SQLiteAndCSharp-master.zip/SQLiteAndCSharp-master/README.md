# SQLite + C Sharp
Sample for article http://devpractice.ru/sqlite-c/
